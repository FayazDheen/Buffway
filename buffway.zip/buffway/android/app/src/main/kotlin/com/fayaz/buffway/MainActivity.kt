package com.fayaz.buffway

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
